<?php


set_time_limit(0);
ignore_user_abort(true);



use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$servername = "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";
$db="camp_email_db";


$camp_name_conn = mysqli_connect($servername, $username, $password,$db);






$frm_email="";
$frm_name="";
$sub_fld="";
$prev_fld="";
$filt_data="";


$mrg_fld="";




function httpGet($url)
{
    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
//  curl_setopt($ch,CURLOPT_HEADER, false); 

    $output=curl_exec($ch);
    curl_close($ch);
    return $output;
}



function update_flg_of_camp_act($conn,$flg,$lst_name,$camp_name,$email){


$update_query_name="update `$lst_name` set `$camp_name`='$flg' where email='$email'";

$conn->query($update_query_name);





}



function update_full_camp_flg($conn,$tbl_name,$update_fld,$update_flg,$camp_id,$camp_fld){





$update_query_name="update `$tbl_name` set `$update_fld`='$update_flg' where `$camp_fld`='$camp_id'";

$conn->query($update_query_name);



}



function send_mail_final($row_data,$template,$camp_name,$conn,$lst_name){


	$frm_mail=$GLOBALS['frm_email'];
	$frm_name=$GLOBALS['frm_name'];
	$sub_fld=$GLOBALS['sub_fld'];
	$prev_fld=$GLOBALS['prev_fld'];
	
	$email=$row_data['email'];


if(isset($row_data[$GLOBALS['mrg_fld']])){

$merg_data=$row_data[$GLOBALS['mrg_fld']];

}else{

$merg_data=$row_data['email'];

}





require_once "vendor/autoload.php";

$mail = new PHPMailer(true);

//Enable SMTP debugging.
$mail->SMTPDebug = 3;                               
//Set PHPMailer to use SMTP.
$mail->isSMTP();            
//Set SMTP host name                          
$mail->Host = "email-smtp.us-east-2.amazonaws.com";
//Set this to true if SMTP host requires authentication to send email
$mail->SMTPAuth = true;                          
//Provide username and password     
$mail->Username = "AKIA4W4EUKY7RI47LWEX";                 
$mail->Password = "BOWO/d0PBBYdXbvENfi4W/jLPufd8895Iw2I/MlGAplV";                           
//If SMTP requires TLS encryption then set it
$mail->SMTPSecure = "tls";                           
//Set TCP port to connect to
$mail->Port = 587;                                   

$mail->From = "ravigorasiya65@gmail.com";
$mail->FromName = $frm_name;

$mail->addAddress($email,$merg_data);

$mail->isHTML(true);




$html_con = $template;



$mail->Subject = $sub_fld;
$mail->Body = $html_con;
$mail->AltBody = $prev_fld;

try {
    $mail->send();
   

update_flg_of_camp_act($conn,1,$lst_name,$camp_name,$email);


} catch (Exception $e) {
    



update_flg_of_camp_act($conn,-1,$lst_name,$camp_name,$email);

}



}















function get_curr_time(){


$tz = 'America/Los_Angeles';
$tz_obj = new DateTimeZone($tz);
$today = new DateTime("now", $tz_obj);
$today_formatted = $today->format('Y-m-d H:i:s');


$late_time=strtotime($today_formatted);

return $late_time;



}

















function get_late_camp($conn){




$sel_camp_data_query="select  id,camp_name,camp_contact_id,min(camp_shed_time) from camp_name_tbl where flg_send='1' LIMIT 1";

$result = $conn->query($sel_camp_data_query);


  // output data of each row
$row = $result->fetch_assoc();




return $row;


}

function get_get_query_of_con_data($con_data){


$get_query="";

foreach ($con_data as $key => $value) {
	
$get_query.=$key."=".urlencode($value)."&";


}



return $get_query;

}




function filt_data_where_clause($data){


$filt_name=$data->name;


if($filt_name=="all_sub"){


  return "";

}else if($filt_name=="tag"){

$filt_data=$data->data;

foreach ($filt_data as $key => $value) {
  
  $ret_str=" tag LIKE '%.".$value."%' or";


}

$ret_str=substr($ret_str, 0, -2);

return $ret_str;

}else if($filt_name=="segment"){

$ret_str="where";

  $filt_data=$data->data;

foreach ($filt_data as $key => $value) {
  
  $ret_str.=" segment LIKE '%".$value."%' or";


}

$ret_str=substr($ret_str, 0, -2);

return $ret_str;

}else if($filt_name=="new_sub"){

}else if($filt_name=="act_sub"){

}else if($filt_name=="inact_sub"){

}



}


function get_sub_data_frm_lst($lst_id,$filt_data,$temp_id,$camp_id){


$servername = "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";
$dbname = "storefile";

$conn_of_lst = mysqli_connect($servername, $username, $password,$dbname);

$filt_data=$GLOBALS['filt_data'];

$filt_data=json_decode($filt_data);


$where_clause=filt_data_where_clause($filt_data);


$sel_con_data="select * from `$lst_id`".$where_clause;



$sel_con_res=$conn_of_lst->query($sel_con_data);



if ($sel_con_res->num_rows > 0) {
  // output data of each row
  while($row = $sel_con_res->fetch_assoc()) {
    


    $get_query=get_get_query_of_con_data($row);



$html_temp_data="http://localhost/html/dash/main/campigns/camp_temp/".$temp_id."?".$get_query."lst_name=".$lst_id;



send_mail_final($row,httpGet($html_temp_data),$camp_id,$conn_of_lst,$lst_id);

  }
} 




}











function sel_lst_data_frm_db($conn,$camp_id,$temp_id_name){



$sel_data_of_lst="select * from camp_contact_tbl where camp_con_id='$camp_id'";

$sel_lst_frm_db=$conn->query($sel_data_of_lst);

while($row = $sel_lst_frm_db->fetch_assoc()) {
    
    $GLOBALS['filt_data']=$row['filt_data'];

$GLOBALS['mrg_fld']=$row['merge_fld'];
get_sub_data_frm_lst($row['list_id'],$row['filt_data'],$temp_id_name,$camp_id);


  }





  update_full_camp_flg($conn,"camp_name_tbl","flg_send","0",$camp_id,"camp_contact_id");


}


function get_sending_credential($sender_id){


$servername = "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";
$db="sender_data";

$conn_sender = mysqli_connect($servername, $username, $password,$db);



$sel_send_id="select * from sender_data where sender_id='".$sender_id."'";


$sel_lst_frm_db=$conn_sender->query($sel_send_id);




$row = $sel_lst_frm_db->fetch_assoc();




$GLOBALS['frm_email']=$row['email'];
$GLOBALS['frm_name']=$row['name'];

}

function get_temp_details($conn,$camp_id,$camp_name){


$sel_data_of_lst="select * from camp_content_tbl where camp_id='$camp_id'";

$sel_lst_frm_db=$conn->query($sel_data_of_lst);




$row = $sel_lst_frm_db->fetch_assoc();



get_sending_credential($row['sender_id']);


$GLOBALS['sub_fld']=$row['sub_fld'];
$GLOBALS['prev_fld']=$row['prev_fld'];

return rawurlencode($camp_id."#".$row['temp_id']).".php";
}


function send_email_camp($conn){


$late_time=get_curr_time();


$late_camp=get_late_camp($conn);









$shed_time=$late_camp["min(camp_shed_time)"];
 

$shed_time_str=strtotime($shed_time);



if($late_time>$shed_time_str and $shed_time_str!==""){


$temp_id=get_temp_details($conn,$late_camp['camp_contact_id'],$late_camp['camp_name']);



sel_lst_data_frm_db($conn,$late_camp['camp_contact_id'],$temp_id);





}





}


while(true){

send_email_camp($camp_name_conn);


}

?>